(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 3696:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _pages_login_login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pages/login/login.component */ 3267);
/* harmony import */ var _pages_register_register_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pages/register/register.component */ 2577);
/* harmony import */ var _pages_stations_find_path_find_path_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/stations/find-path/find-path.component */ 6983);
/* harmony import */ var _pages_stations_station_dashboard_station_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/stations/station-dashboard/station-dashboard.component */ 318);
/* harmony import */ var _pages_stations_stations_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/stations/stations.component */ 4963);
/* harmony import */ var _services_authguard_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./services/authguard.service */ 4805);









const routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        component: _pages_login_login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent
    },
    {
        path: 'register',
        component: _pages_register_register_component__WEBPACK_IMPORTED_MODULE_1__.RegisterComponent
    },
    {
        path: 'stations',
        component: _pages_stations_stations_component__WEBPACK_IMPORTED_MODULE_4__.StationsComponent,
        canActivate: [_services_authguard_service__WEBPACK_IMPORTED_MODULE_5__.AuthguardService]
    },
    {
        path: 'stations/:stationId',
        component: _pages_stations_station_dashboard_station_dashboard_component__WEBPACK_IMPORTED_MODULE_3__.StationDashboardComponent,
        canActivate: [_services_authguard_service__WEBPACK_IMPORTED_MODULE_5__.AuthguardService]
    },
    {
        path: 'path',
        component: _pages_stations_find_path_find_path_component__WEBPACK_IMPORTED_MODULE_2__.FindPathComponent,
        canActivate: [_services_authguard_service__WEBPACK_IMPORTED_MODULE_5__.AuthguardService]
    },
    {
        path: '**',
        redirectTo: ''
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_8__.PreloadAllModules, onSameUrlNavigation: 'reload' })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 2050:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./app.component.html */ 5158);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 836);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/auth.service */ 6636);





let AppComponent = class AppComponent {
    constructor(authService) {
        this.authService = authService;
        this.loginPage = { title: 'Login', url: '/login', icon: 'log-in' };
        this.stationsPage = { title: 'Stations', url: '/stations', icon: 'flag' };
        this.registerPage = { title: 'Register', url: '/register', icon: 'person-add' };
        this.findPathPage = { title: 'Optimal Station Path', url: '/path', icon: 'person-add' };
        this.logoutPage = { title: 'Logout', url: '/logout', icon: 'log-out' };
    }
    onLogout() {
        this.authService.logout();
    }
};
AppComponent.ctorParameters = () => [
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-root',
        template: _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_app_component_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 4750:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ 6219);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common/http */ 3981);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic/storage-angular */ 2688);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 2050);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 3696);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 8267);
/* harmony import */ var _pages_login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/login/login.component */ 3267);
/* harmony import */ var _pages_register_register_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/register/register.component */ 2577);
/* harmony import */ var _services_jwt_interceptor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./services/jwt.interceptor */ 622);
/* harmony import */ var _pages_stations_stations_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/stations/stations.component */ 4963);
/* harmony import */ var _pages_stations_station_dashboard_station_dashboard_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/stations/station-dashboard/station-dashboard.component */ 318);
/* harmony import */ var _pages_stations_find_path_find_path_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/stations/find-path/find-path.component */ 6983);

















let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent, _pages_login_login_component__WEBPACK_IMPORTED_MODULE_2__.LoginComponent, _pages_register_register_component__WEBPACK_IMPORTED_MODULE_3__.RegisterComponent, _pages_stations_stations_component__WEBPACK_IMPORTED_MODULE_5__.StationsComponent, _pages_stations_station_dashboard_station_dashboard_component__WEBPACK_IMPORTED_MODULE_6__.StationDashboardComponent, _pages_stations_find_path_find_path_component__WEBPACK_IMPORTED_MODULE_7__.FindPathComponent],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.BrowserModule, _angular_common__WEBPACK_IMPORTED_MODULE_11__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule.forRoot(),
            _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_13__.IonicStorageModule.forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.ReactiveFormsModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HttpClientModule],
        providers: [{
                provide: _angular_router__WEBPACK_IMPORTED_MODULE_16__.RouteReuseStrategy,
                useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicRouteStrategy
            }, { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_15__.HTTP_INTERCEPTORS, useClass: _services_jwt_interceptor__WEBPACK_IMPORTED_MODULE_4__.JwtInterceptor, multi: true },],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 3267:
/*!************************************************!*\
  !*** ./src/app/pages/login/login.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_login_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./login.component.html */ 9777);
/* harmony import */ var _login_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.component.scss */ 4754);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 6636);








let LoginComponent = class LoginComponent {
    constructor(formBuilder, loadingController, toastController, authService, router) {
        this.formBuilder = formBuilder;
        this.loadingController = loadingController;
        this.toastController = toastController;
        this.authService = authService;
        this.router = router;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.loginForm = this.formBuilder.group({
                username: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(5)]],
                password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.minLength(8)]]
            });
        });
    }
    submitLoginForm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            if (this.loginForm.valid) {
                this.loadingIndicator = yield this.loadingController.create({
                    message: 'Loading...'
                });
                this.loginToast = yield this.toastController.create({
                    duration: 2500
                });
                yield this.loadingIndicator.present();
                this.authService.initAuthService();
                this.authService.preSignIn().subscribe(preSignInData => {
                    const signInId = preSignInData.signInId;
                    const username = this.loginForm.value.username;
                    const password = this.loginForm.value.password;
                    this.authService.signIn(signInId, username, password).subscribe(signInData => {
                        const authCode = signInData.authCode;
                        this.authService.postSignIn(authCode).subscribe((postSignInData) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                            const accessToken = postSignInData.accessToken;
                            const refreshToken = postSignInData.refreshToken;
                            this.authService.setTokens(accessToken, refreshToken);
                            this.loadingIndicator.dismiss();
                            this.loginToast.message = 'Successfully connected!';
                            this.loginToast.color = 'success';
                            yield this.loginToast.present();
                            this.authService.activateRunner();
                            this.router.navigate(['/stations']);
                        }), (err) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                            this.loadingIndicator.dismiss();
                            this.loginToast.message = 'Login Failed!';
                            this.loginToast.color = 'danger';
                            yield this.loginToast.present();
                            console.log(err);
                        }));
                        this.loginForm.reset();
                    }, (err) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                        this.loadingIndicator.dismiss();
                        this.loginToast.message = 'Login Failed!';
                        this.loginToast.color = 'danger';
                        yield this.loginToast.present();
                        console.log(err);
                        this.loginForm.reset();
                    }));
                }, (err) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                    this.loadingIndicator.dismiss();
                    this.loginToast.message = 'Login Failed!';
                    this.loginToast.color = 'danger';
                    yield this.loginToast.present();
                    console.log(err);
                    this.loginForm.reset();
                }));
            }
        });
    }
};
LoginComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
LoginComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-login',
        template: _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_login_component_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_login_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginComponent);



/***/ }),

/***/ 2577:
/*!******************************************************!*\
  !*** ./src/app/pages/register/register.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterComponent": () => (/* binding */ RegisterComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_register_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./register.component.html */ 2888);
/* harmony import */ var _register_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.component.scss */ 9963);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 8346);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 6636);








let RegisterComponent = class RegisterComponent {
    constructor(formBuilder, loadingController, toastController, authService, router) {
        this.formBuilder = formBuilder;
        this.loadingController = loadingController;
        this.toastController = toastController;
        this.authService = authService;
        this.router = router;
    }
    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            firstname: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]],
            lastname: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required]],
            username: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(5)]],
            password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.minLength(8)]],
            email: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.email]],
        });
    }
    submitRegisterForm() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.loadingIndicator = yield this.loadingController.create({
                message: 'Loading...'
            });
            this.registerToast = yield this.toastController.create({
                duration: 5000
            });
            yield this.loadingIndicator.present();
            this.authService.signUp(this.registerForm.value.firstname, this.registerForm.value.lastname, this.registerForm.value.username, this.registerForm.value.password, this.registerForm.value.email).subscribe((_) => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
                this.loadingIndicator.dismiss();
                this.registerToast.message = 'Account created successfully!';
                this.registerToast.color = 'success';
                yield this.registerToast.present();
                this.router.navigate(['/login']);
            }), (err) => (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
                this.loadingIndicator.dismiss();
                this.registerToast.message = 'There was a problem while creating the account!';
                this.registerToast.color = 'danger';
                yield this.registerToast.present();
                console.log(err);
            }));
        });
    }
};
RegisterComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
RegisterComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-register',
        template: _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_register_component_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_register_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegisterComponent);



/***/ }),

/***/ 6983:
/*!*****************************************************************!*\
  !*** ./src/app/pages/stations/find-path/find-path.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FindPathComponent": () => (/* binding */ FindPathComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_find_path_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./find-path.component.html */ 7525);
/* harmony import */ var _find_path_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./find-path.component.scss */ 6755);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/geolocation */ 2233);
/* harmony import */ var src_app_services_stations_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/stations.service */ 5178);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! leaflet */ 951);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(leaflet__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var leaflet_routing_machine__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! leaflet-routing-machine */ 739);
/* harmony import */ var leaflet_routing_machine__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(leaflet_routing_machine__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 1119);









let FindPathComponent = class FindPathComponent {
    constructor(stationsService) {
        this.stationsService = stationsService;
        this.stations = [];
        this.existsStations = new rxjs__WEBPACK_IMPORTED_MODULE_6__.BehaviorSubject(false);
        this.existsStations.next(false);
    }
    ionViewDidEnter() { this.leafletMap(); }
    leafletMap() {
        this.map = leaflet__WEBPACK_IMPORTED_MODULE_4__.map('findPathMap');
        leaflet__WEBPACK_IMPORTED_MODULE_4__.tileLayer('http://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png', {
            attribution: 'edupala.com',
        }).addTo(this.map);
        this.stationsService.getUserStations().subscribe(data => {
            this.stations = data;
            let waypoints = this.stations.filter(value => value.isEnabled).map(value => leaflet__WEBPACK_IMPORTED_MODULE_4__.latLng(value.station_lat, value.station_long));
            if (waypoints.length) {
                _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_2__.Geolocation.getCurrentPosition().then(userCoords => {
                    waypoints = [leaflet__WEBPACK_IMPORTED_MODULE_4__.latLng(userCoords.coords.latitude, userCoords.coords.longitude), ...waypoints];
                    console.log(waypoints);
                    leaflet__WEBPACK_IMPORTED_MODULE_4__.Routing.control({
                        waypoints: waypoints,
                    }).addTo(this.map);
                });
                this.existsStations.next(true);
            }
            else {
                this.existsStations.next(false);
            }
        });
    }
    ngOnInit() { }
    ngOnDestroy() {
        this.map.remove();
    }
};
FindPathComponent.ctorParameters = () => [
    { type: src_app_services_stations_service__WEBPACK_IMPORTED_MODULE_3__.StationsService }
];
FindPathComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-find-path',
        template: _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_find_path_component_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_find_path_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], FindPathComponent);



/***/ }),

/***/ 318:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/stations/station-dashboard/station-dashboard.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationDashboardComponent": () => (/* binding */ StationDashboardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_station_dashboard_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./station-dashboard.component.html */ 7078);
/* harmony import */ var _station_dashboard_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./station-dashboard.component.scss */ 5273);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var src_app_services_stations_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/stations.service */ 5178);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! leaflet */ 951);
/* harmony import */ var leaflet__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(leaflet__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ 9243);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);









let StationDashboardComponent = class StationDashboardComponent {
    constructor(route, stationsService, toastController) {
        this.route = route;
        this.stationsService = stationsService;
        this.toastController = toastController;
        this.loadedData = false;
        this.stationId = this.route.snapshot.params['stationId'];
    }
    ionViewDidEnter() { this.leafletMap(); }
    leafletMap() {
        this.map = leaflet__WEBPACK_IMPORTED_MODULE_3__.map('detailsMap').setView([this.station.station_lat, this.station.station_long], 12);
        leaflet__WEBPACK_IMPORTED_MODULE_3__.tileLayer('http://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png', {
            attribution: 'edupala.com',
        }).addTo(this.map);
        const markPoint = leaflet__WEBPACK_IMPORTED_MODULE_3__.marker([this.station.station_lat, this.station.station_long], {
            icon: leaflet__WEBPACK_IMPORTED_MODULE_3__.icon({
                iconUrl: 'assets/marker-icon-2x.png',
                shadowUrl: 'assets/marker-shadow.png',
                iconSize: [30, 80],
                shadowSize: [40, 50],
                iconAnchor: [22, 94],
                shadowAnchor: [18, 62],
                popupAnchor: [-3, -76] // point from which the popup should open relative to the iconAnchor
            })
        });
        this.map.addLayer(markPoint);
    }
    ngOnInit() {
        this.stationsService.getStationByStationId(this.stationId).subscribe(data => {
            this.loadedData = true;
            this.station = data;
            this.station.lastUpdatedAt = moment__WEBPACK_IMPORTED_MODULE_4__(this.station.lastUpdatedAt).fromNow();
        });
    }
    ngOnDestroy() {
        this.map.remove();
    }
    doRefresh(event) {
        this.stationsService.getStationByStationId(this.stationId).subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.loadedData = true;
            this.station = data;
            this.station.lastUpdatedAt = moment__WEBPACK_IMPORTED_MODULE_4__(this.station.lastUpdatedAt).fromNow();
            this.updateToast = yield this.toastController.create({
                duration: 2500,
                message: 'Updated!',
                color: 'success',
                animated: true,
                position: 'top'
            });
            yield this.updateToast.present();
            event.target.complete();
        }));
    }
};
StationDashboardComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.ActivatedRoute },
    { type: src_app_services_stations_service__WEBPACK_IMPORTED_MODULE_2__.StationsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController }
];
StationDashboardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-station-dashboard',
        template: _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_station_dashboard_component_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_station_dashboard_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], StationDashboardComponent);



/***/ }),

/***/ 4963:
/*!******************************************************!*\
  !*** ./src/app/pages/stations/stations.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationsComponent": () => (/* binding */ StationsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_stations_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./stations.component.html */ 9340);
/* harmony import */ var _stations_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stations.component.scss */ 5733);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor-community/barcode-scanner */ 6789);
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/core */ 2960);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 2233);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 8099);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/auth.service */ 6636);
/* harmony import */ var src_app_services_stations_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/stations.service */ 5178);











let StationsComponent = class StationsComponent {
    constructor(stationService, authService, toastController, router) {
        this.stationService = stationService;
        this.authService = authService;
        this.toastController = toastController;
        this.router = router;
        this.isAddStationModalOpen = false;
        this.isScanning = false;
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Capacitor.isNativePlatform()) {
            _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner.stopScan();
            _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner.prepare();
        }
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.stationService.getUserStations().subscribe(data => {
                this.stations = data;
            });
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Capacitor.isNativePlatform()) {
                yield _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner.checkPermission({ force: true });
            }
        });
    }
    openStationModal() {
        this.isAddStationModalOpen = false;
        this.isAddStationModalOpen = true;
    }
    closeStationModal() {
        this.isAddStationModalOpen = false;
    }
    scanQRCode() {
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Capacitor.isNativePlatform()) {
            this.startScan();
        }
    }
    startScan() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.isScanning = true;
            yield _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner.hideBackground();
            const result = yield _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner.startScan();
            this.isScanning = false;
            if (result.hasContent) {
                yield _capacitor_community_barcode_scanner__WEBPACK_IMPORTED_MODULE_2__.BarcodeScanner.showBackground();
                var resultJSON;
                try {
                    resultJSON = JSON.parse(result.content);
                }
                catch (e) {
                    resultJSON = null;
                }
                if (!resultJSON) {
                    this.updateToast = yield this.toastController.create({
                        duration: 4500,
                        message: 'Wrong QR Code, please scan it directly from the station!',
                        color: 'danger'
                    });
                    yield this.updateToast.present();
                }
                else {
                    const stationId = resultJSON.station_id;
                    const stationName = resultJSON.station_name;
                    if (!(stationId && stationName)) {
                        this.updateToast = yield this.toastController.create({
                            duration: 4500,
                            message: 'Wrong QR Code, please scan it directly from the station!',
                            color: 'danger'
                        });
                        yield this.updateToast.present();
                    }
                    else {
                        // get the coordinates
                        const coordinates = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.getCurrentPosition();
                        // check if station is Added
                        this.stationService.connectToStation(stationId, stationName, coordinates.coords.latitude, coordinates.coords.longitude)
                            .subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                            this.isAddStationModalOpen = false;
                            this.stationService.getUserStations().subscribe((stationData) => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                                this.stations = stationData;
                                this.updateToast = yield this.toastController.create({
                                    duration: 2500,
                                    message: 'Connected to station successfully!',
                                    color: 'success'
                                });
                                yield this.updateToast.present();
                            }));
                        }), (err) => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                            this.updateToast = yield this.toastController.create({
                                duration: 2500,
                                message: 'The station has been already added to an account!',
                                color: 'danger'
                            });
                            yield this.updateToast.present();
                        }));
                    }
                }
            }
        });
    }
    ;
    enableStation(stationId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.updateToast = yield this.toastController.create({
                duration: 2500,
                message: 'Enabled station successfully!',
                color: 'success'
            });
            yield this.updateToast.dismiss();
            this.stationService.enableUserStation(stationId).subscribe(_ => {
                this.stationService.getUserStations().subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                    this.stations = data;
                    yield this.updateToast.present();
                }));
            });
        });
    }
    disableStation(stationId) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            this.updateToast = yield this.toastController.create({
                duration: 2500,
                message: 'Disabled station successfully!',
                color: 'success'
            });
            this.stationService.disableUserStation(stationId).subscribe(_ => {
                this.stationService.getUserStations().subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
                    this.stations = data;
                    yield this.updateToast.present();
                }));
            });
        });
    }
    goToStationDetails(stationId) {
        this.router.navigate(['stations', stationId]);
    }
    isNativePlatform() {
        return _capacitor_core__WEBPACK_IMPORTED_MODULE_3__.Capacitor.isNativePlatform();
    }
};
StationsComponent.ctorParameters = () => [
    { type: src_app_services_stations_service__WEBPACK_IMPORTED_MODULE_6__.StationsService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_5__.AuthService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router }
];
StationsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-stations',
        template: _C_cot_pollution_monitoring_system_Mobile_node_modules_ngtools_webpack_src_loaders_direct_resource_js_stations_component_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_stations_component_scss__WEBPACK_IMPORTED_MODULE_1__]
    })
], StationsComponent);



/***/ }),

/***/ 6636:
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ 3981);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! uuid */ 9232);
/* harmony import */ var _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @auth0/angular-jwt */ 704);
/* harmony import */ var crypto_js_hmac_sha256__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! crypto-js/hmac-sha256 */ 3242);
/* harmony import */ var crypto_js_hmac_sha256__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto_js_hmac_sha256__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var crypto_js_enc_base64__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! crypto-js/enc-base64 */ 5125);
/* harmony import */ var crypto_js_enc_base64__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(crypto_js_enc_base64__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/storage-angular */ 7897);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ 8260);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 1119);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _stations_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stations.service */ 5178);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 8099);













let AuthService = class AuthService {
    constructor(toastController, storage, http, router, stationServices) {
        this.toastController = toastController;
        this.storage = storage;
        this.http = http;
        this.router = router;
        this.stationServices = stationServices;
        this.backendUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.backendUrl;
        this.sha256Secret = _environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.sha265Secret;
        // for showing notifications
        this.notificationRunner = null;
        this.authState = new rxjs__WEBPACK_IMPORTED_MODULE_4__.BehaviorSubject(false);
        this.jwtHelper = new _auth0_angular_jwt__WEBPACK_IMPORTED_MODULE_5__.JwtHelperService();
        this.init();
    }
    init() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.create();
            yield this.storage.clear();
        });
    }
    set(key, value) {
        var _a;
        (_a = this.storage) === null || _a === void 0 ? void 0 : _a.set(key, value);
    }
    get(key) {
        var _a;
        return (_a = this.storage) === null || _a === void 0 ? void 0 : _a.get(key);
    }
    initAuthService() {
        this.codeVerifier = (0,uuid__WEBPACK_IMPORTED_MODULE_7__["default"])();
        this.codeChallenge = crypto_js_enc_base64__WEBPACK_IMPORTED_MODULE_1__.stringify(crypto_js_hmac_sha256__WEBPACK_IMPORTED_MODULE_0__(this.codeVerifier, this.sha256Secret));
        this.clientId = (0,uuid__WEBPACK_IMPORTED_MODULE_7__["default"])();
    }
    preSignIn() {
        this.preAuthorization = 'Bearer ' + btoa(this.clientId + ':' + this.codeChallenge);
        // eslint-disable-next-line @typescript-eslint/naming-convention
        return this.http.post(`${this.backendUrl}/authorize`, null, { headers: { 'Pre-Authorization': this.preAuthorization } });
    }
    signIn(signInId, username, password) {
        this.signInId = signInId;
        return this.http.post(`${this.backendUrl}/authenticate`, {
            signInId,
            username,
            password
        });
    }
    postSignIn(authCode) {
        this.authCode = authCode;
        this.postAuthorization = 'Bearer ' + btoa(this.authCode + ':' + this.codeVerifier);
        // eslint-disable-next-line @typescript-eslint/naming-convention
        return this.http.post(`${this.backendUrl}/oauth/token`, null, { headers: { 'Post-Authorization': this.postAuthorization } });
    }
    setTokens(accessToken, refreshToken) {
        this.set('accessToken', accessToken);
        this.set('refreshToken', refreshToken);
        this.authToken = accessToken;
        this.setUserId(accessToken);
        this.authState.next(true);
    }
    setUserId(accessToken) {
        const accessTokenPayload = this.jwtHelper.decodeToken(accessToken);
        this.set('connectedUserId', accessTokenPayload.id);
    }
    getUserId() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            return yield this.get('connectedUserId');
        });
    }
    logout() {
        this.storage.clear().then(() => {
            this.router.navigate(['login']);
            this.authState.next(false);
        });
        clearInterval(this.notificationRunner);
    }
    signUp(firstname, lastname, username, password, email) {
        return this.http.post(`${this.backendUrl}/signup`, {
            firstname, lastname, username, password, email
        });
    }
    isAuthenticated() {
        return this.authState.value;
    }
    getAccessToken() {
        return this.authToken;
    }
    activateRunner() {
        setInterval(() => {
            this.stationServices.getUserStations().subscribe(stations => {
                for (let station of stations) {
                    {
                    }
                }
            });
        }, 5000);
    }
};
AuthService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_9__.Storage },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HttpClient },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_11__.Router },
    { type: _stations_service__WEBPACK_IMPORTED_MODULE_3__.StationsService }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_12__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 4805:
/*!***********************************************!*\
  !*** ./src/app/services/authguard.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthguardService": () => (/* binding */ AuthguardService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 6636);




let AuthguardService = class AuthguardService {
    constructor(authService, router) {
        this.authService = authService;
        this.router = router;
    }
    canActivate(route, state) {
        if (this.authService.isAuthenticated()) {
            return this.authService.isAuthenticated();
        }
        else {
            this.router.navigate(['/login']);
        }
    }
};
AuthguardService.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__.Router }
];
AuthguardService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthguardService);



/***/ }),

/***/ 622:
/*!*********************************************!*\
  !*** ./src/app/services/jwt.interceptor.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JwtInterceptor": () => (/* binding */ JwtInterceptor)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 3252);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/storage-angular */ 7897);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 6636);





let JwtInterceptor = class JwtInterceptor {
    constructor(storage, router, authService) {
        this.storage = storage;
        this.router = router;
        this.authService = authService;
    }
    intercept(req, next) {
        if (this.authService.isAuthenticated()) {
            const authReq = req.clone({
                headers: req.headers.set('Authorization', 'Bearer ' + this.getToken())
                    .append('Access-Control-Allow-Origin', '*')
            });
            return next.handle(authReq);
        }
        return next.handle(req);
    }
    getToken() {
        return this.authService.getAccessToken();
    }
};
JwtInterceptor.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_1__.Storage },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService }
];
JwtInterceptor = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Injectable)()
], JwtInterceptor);



/***/ }),

/***/ 5178:
/*!**********************************************!*\
  !*** ./src/app/services/stations.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StationsService": () => (/* binding */ StationsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 8806);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 3981);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 8260);




let StationsService = class StationsService {
    constructor(http) {
        this.http = http;
        this.backendUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.backendUrl;
    }
    getUserStations() {
        return this.http.get(`${this.backendUrl}/stations`);
    }
    getStationByStationId(stationId) {
        return this.http.get(`${this.backendUrl}/stations/${stationId}`);
    }
    connectToStation(stationId, stationName, stationLat, stationLong) {
        return this.http.post(`${this.backendUrl}/stations`, {
            stationId, stationName, stationLat, stationLong
        });
    }
    enableUserStation(stationId) {
        return this.http.get(`${this.backendUrl}/stations/${stationId}/enable`);
    }
    disableUserStation(stationId) {
        return this.http.get(`${this.backendUrl}/stations/${stationId}/disable`);
    }
};
StationsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
StationsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], StationsService);



/***/ }),

/***/ 8260:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    backendUrl: 'https://api.pmscot.me',
    sha265Secret: 'abcdefgh'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 271:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4001);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 4378);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 4750);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 8260);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		3477,
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		7196,
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		8081,
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		5017,
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		9721,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		9216,
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		6612,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		2694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		2938,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		1379,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		7552,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		7218,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		7479,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		4134,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		1439,
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		6397,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		3296,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		2413,
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		9411,
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		9133,
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		9003,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		6065,
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		6991,
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		2947,
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		5919,
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		3109,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		9459,
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		301,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		3799,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		2140,
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		6197,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		1975,
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		8387,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		8659,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		6404,
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		5253,
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		2619,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		2871,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		7668,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		5342,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		174,
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		6185,
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		7337,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		4833,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		9468,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5705,
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		7463,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 5158:
/*!***************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/app.component.html ***!
  \***************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <ion-menu contentId=\"main-content\" type=\"overlay\">\n      <ion-content>\n        <ion-list id=\"inbox-list\">\n          <ion-list-header>Pollution Tracking System</ion-list-header>\n          <ion-note>Menu</ion-note>\n          <ion-menu-toggle auto-hide=\"false\">\n            <ion-item *ngIf=\"!authService.isAuthenticated()\" routerDirection=\"root\" [routerLink]=\"[loginPage.url]\"\n              lines=\"none\" detail=\"false\" routerLinkActive=\"selected\">\n              <ion-icon slot=\"start\" [ios]=\"loginPage.icon + '-outline'\" [md]=\"loginPage.icon + '-sharp'\"></ion-icon>\n              <ion-label>{{ loginPage.title }}</ion-label>\n            </ion-item>\n            <ion-item *ngIf=\"!authService.isAuthenticated()\" routerDirection=\"root\" [routerLink]=\"[registerPage.url]\"\n              lines=\"none\" detail=\"false\" routerLinkActive=\"selected\">\n              <ion-icon slot=\"start\" [ios]=\"registerPage.icon + '-outline'\" [md]=\"registerPage.icon + '-sharp'\">\n              </ion-icon>\n              <ion-label>{{ registerPage.title }}</ion-label>\n            </ion-item>\n            <ion-item *ngIf=\"authService.isAuthenticated()\" routerDirection=\"root\" [routerLink]=\"[stationsPage.url]\"\n              lines=\"none\" detail=\"false\" routerLinkActive=\"selected\">\n              <ion-icon slot=\"start\" [ios]=\"stationsPage.icon + '-outline'\" [md]=\"stationsPage.icon + '-sharp'\">\n              </ion-icon>\n              <ion-label>{{ stationsPage.title }}</ion-label>\n            </ion-item>\n            <ion-item *ngIf=\"authService.isAuthenticated()\" routerDirection=\"root\" [routerLink]=\"[findPathPage.url]\"\n              lines=\"none\" detail=\"false\" routerLinkActive=\"selected\">\n              <ion-icon slot=\"start\" [ios]=\"findPathPage.icon + '-outline'\" [md]=\"findPathPage.icon + '-sharp'\">\n              </ion-icon>\n              <ion-label>{{ findPathPage.title }}</ion-label>\n            </ion-item>\n            <ion-item *ngIf=\"authService.isAuthenticated()\" (click)=\"onLogout()\" lines=\"none\" detail=\"false\">\n              <ion-icon slot=\"start\" [ios]=\"logoutPage.icon + '-outline'\" [md]=\"logoutPage.icon + '-sharp'\"></ion-icon>\n              <ion-label>{{ logoutPage.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>");

/***/ }),

/***/ 9777:
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/login/login.component.html ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header>\n    <ion-toolbar>\n      <ion-title slot=\"start\">Welcome to PMS</ion-title>\n      <ion-menu-toggle slot=\"end\">\n        <ion-menu-button>\n          <ion-icon name=\"reorder-three-outline\"></ion-icon>\n        </ion-menu-button>\n      </ion-menu-toggle>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-card>\n    <ion-card-content>\n      Track pollution within your city with a few button presses.\n    </ion-card-content>\n  </ion-card>\n\n  <form [formGroup]=\"loginForm\" (ngSubmit)=\"submitLoginForm()\" (keyup.enter)=\"submitLoginForm()\" novalidate>\n    <ion-card>\n      <ion-card-header>\n        <ion-card-title>Login</ion-card-title>\n      </ion-card-header>\n      <ion-card-content>\n        <ion-item>\n          <ion-label position=\"floating\">Username</ion-label>\n          <ion-input formControlName=\"username\" type=\"text\"></ion-input>\n        </ion-item>\n        <div class=\"error ion-padding\"\n          *ngIf=\"loginForm.controls.username.dirty && loginForm.controls.username.errors?.required\">\n          Name is required.\n        </div>\n        <div class=\"error ion-padding\"\n          *ngIf=\"loginForm.controls.username.dirty && loginForm.controls.username.errors?.minlength\">\n          Name should be min 5 chars long.\n        </div>\n        <ion-item>\n          <ion-label position=\"floating\">Password</ion-label>\n          <ion-input formControlName=\"password\" type=\"password\"></ion-input>\n        </ion-item>\n        <div class=\"error ion-padding\"\n          *ngIf=\"loginForm.controls.password.dirty && loginForm.controls.password.errors?.required\">\n          Password is required.\n        </div>\n        <div class=\"error ion-padding\"\n          *ngIf=\"loginForm.controls.password.dirty && loginForm.controls.password.errors?.minlength\">\n          Password should be min 8 chars long.\n        </div>\n\n        <ion-row>\n          <ion-col>\n            <ion-button type=\"submit\" color=\"primary\" expand=\"block\" [disabled]=\"loginForm.invalid\">Login</ion-button>\n          </ion-col>\n        </ion-row>\n      </ion-card-content>\n    </ion-card>\n  </form>\n  <ion-content class=\"ion-text-center\">\n    <div>\n      <h4 class=\"gray\">Don't have an account? <a routerLink=\"/register\">Sign Up</a></h4>\n    </div>\n  </ion-content>\n</ion-content>");

/***/ }),

/***/ 2888:
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/register/register.component.html ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n  <ion-header>\n    <ion-toolbar>\n      <ion-title slot=\"start\">Welcome to PMS</ion-title>\n      <ion-menu-toggle slot=\"end\">\n        <ion-menu-button>\n          <ion-icon name=\"reorder-three-outline\"></ion-icon>\n        </ion-menu-button>\n      </ion-menu-toggle>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-card>\n    <ion-card-content>\n      Track pollution within your city with a few button presses.\n    </ion-card-content>\n  </ion-card>\n\n  <form [formGroup]=\"registerForm\" (ngSubmit)=\"submitRegisterForm()\" (keyup.enter)=\"submitRegisterForm()\" novalidate>\n    <ion-card>\n      <ion-card-header>\n        <ion-card-title>Sign up</ion-card-title>\n      </ion-card-header>\n      <ion-card-content>\n\n        <ion-item>\n          <ion-label position=\"floating\">Username</ion-label>\n          <ion-input formControlName=\"username\" type=\"text\"></ion-input>\n        </ion-item>\n        <div class=\"error ion-padding\"\n          *ngIf=\"registerForm.controls.username.dirty && registerForm.controls.username.errors?.required\">\n          Name is required.\n        </div>\n        <div class=\"error ion-padding\"\n          *ngIf=\"registerForm.controls.username.dirty && registerForm.controls.username.errors?.minlength\">\n          Name should be min 5 chars long.\n        </div>\n\n        <ion-item>\n          <ion-label position=\"floating\">First Name</ion-label>\n          <ion-input formControlName=\"firstname\" type=\"text\"></ion-input>\n        </ion-item>\n        <div class=\"error ion-padding\"\n          *ngIf=\"registerForm.controls.firstname.dirty && registerForm.controls.firstname.errors?.required\">\n          Name is required.\n        </div>\n\n        <ion-item>\n          <ion-label position=\"floating\">Last Name</ion-label>\n          <ion-input formControlName=\"lastname\" type=\"text\"></ion-input>\n        </ion-item>\n        <div class=\"error ion-padding\"\n          *ngIf=\"registerForm.controls.lastname.dirty && registerForm.controls.lastname.errors?.required\">\n          Name is required.\n        </div>\n\n        <ion-item>\n          <ion-label position=\"floating\">Email</ion-label>\n          <ion-input formControlName=\"email\" type=\"email\"></ion-input>\n        </ion-item>\n        <div class=\"error ion-padding\"\n          *ngIf=\"registerForm.controls.email.dirty && registerForm.controls.email.errors?.required\">\n          Email is required.\n        </div>\n        <div class=\"error ion-padding\"\n          *ngIf=\"registerForm.controls.email.dirty && registerForm.controls.email.errors?.email\">\n          Email should be valid.\n        </div>\n\n        <ion-item>\n          <ion-label position=\"floating\">Password</ion-label>\n          <ion-input formControlName=\"password\" type=\"password\"></ion-input>\n        </ion-item>\n        <div class=\"error ion-padding\"\n          *ngIf=\"registerForm.controls.password.dirty && registerForm.controls.password.errors?.required\">\n          Password is required.\n        </div>\n        <div class=\"error ion-padding\"\n          *ngIf=\"registerForm.controls.password.dirty && registerForm.controls.password.errors?.minlength\">\n          Password should be min 8 chars long.\n        </div>\n\n        <ion-row>\n          <ion-col>\n            <ion-button type=\"submit\" color=\"primary\" expand=\"block\" [disabled]=\"registerForm.invalid\">Sign Up\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </ion-card-content>\n    </ion-card>\n  </form>\n  <ion-content class=\"ion-text-center\">\n    <div>\n      <h4 class=\"gray\">Already have an account? <a routerLink=\"/login\">Sign In</a></h4>\n    </div>\n  </ion-content>\n</ion-content>");

/***/ }),

/***/ 7525:
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/stations/find-path/find-path.component.html ***!
  \**********************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header>\n  <ion-toolbar>\n    <ion-title slot=\"start\">Path between Active Stations</ion-title>\n    <ion-menu-toggle slot=\"end\">\n      <ion-menu-button>\n        <ion-icon name=\"reorder-three-outline\"></ion-icon>\n      </ion-menu-button>\n    </ion-menu-toggle>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-text *ngIf=\"!existsStations.value\" style=\"text-align: center\">\n        <h1> You need to have at least one active station</h1>\n      </ion-text>\n    </ion-col>\n  </ion-row>\n  <div id=\"findPathMap\" [ngClass]=\"{'ion-hide': !existsStations.value }\" style=\"width: 100%; height: 92vh\"></div>\n</ion-content>");

/***/ }),

/***/ 7078:
/*!**************************************************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/stations/station-dashboard/station-dashboard.component.html ***!
  \**************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content *ngIf=\"loadedData\">\n  <ion-header>\n    <ion-toolbar>\n      <ion-title slot=\"start\">{{ station.station_name }}</ion-title>\n      <ion-menu-toggle slot=\"end\">\n        <ion-menu-button>\n          <ion-icon name=\"reorder-three-outline\"></ion-icon>\n        </ion-menu-button>\n      </ion-menu-toggle>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-card>\n    <ion-card-content>View latest info on this station</ion-card-content>\n  </ion-card>\n\n  <div id=\"detailsMap\" style=\"width: 100%; height: 55vh\"></div>\n\n  <ion-list>\n    <ion-item>\n      <ion-label>Is activated:</ion-label>\n      <ion-note slot=\"end\">{{ station.isEnabled ? 'Activated' : 'Disabled' }}</ion-note>\n    </ion-item>\n    <ion-item>\n      <ion-label>Last Updated</ion-label>\n      <ion-note slot=\"end\">{{ station.lastUpdatedAt }}</ion-note>\n    </ion-item>\n    <ion-item>\n      <ion-label>Latest Air Pollution level</ion-label>\n      <ion-note slot=\"end\">{{ station.lastAirPollutionLevel }}</ion-note>\n    </ion-item>\n  </ion-list>\n\n</ion-content>");

/***/ }),

/***/ 9340:
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/@ngtools/webpack/src/loaders/direct-resource.js!./src/app/pages/stations/stations.component.html ***!
  \***********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header *ngIf=\"!isScanning\">\n  <ion-toolbar>\n    <ion-title slot=\"start\">Stations List</ion-title>\n    <ion-menu-toggle slot=\"end\">\n      <ion-menu-button>\n        <ion-icon name=\"reorder-three-outline\"></ion-icon>\n      </ion-menu-button>\n    </ion-menu-toggle>\n  </ion-toolbar>\n</ion-header>\n<br>\n<ion-content *ngIf=\"!isScanning\">\n  <ion-card>\n    <ion-card-content>Add, enable, disable and view your stations information.</ion-card-content>\n  </ion-card>\n\n  <ion-list>\n    <ion-item-sliding *ngFor=\"let station of stations; let index = index\">\n      <ion-item>\n        <ion-label>{{station.station_name}}</ion-label>\n        <ion-label>{{station.isEnabled ? 'On' : 'Off'}}</ion-label>\n      </ion-item>\n      <ion-item-options side=\"end\">\n        <ion-item-option *ngIf=\"!station.isEnabled\" color=\"success\" (click)=\"enableStation(station.id)\">Enable\n        </ion-item-option>\n        <ion-item-option *ngIf=\"station.isEnabled\" color=\"danger\" (click)=\"disableStation(station.id)\">Disable\n        </ion-item-option>\n        <ion-item-option color=\"light\" (click)=\"goToStationDetails(station.id)\">Details</ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n  </ion-list>\n\n  <ion-fab *ngIf=\"isNativePlatform()\" side=\"end\" vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n    <ion-fab-button (click)=\"openStationModal()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>\n\n\n<ion-modal [isOpen]=\"isAddStationModalOpen\" *ngIf=\"!isScanning\">\n  <ng-template>\n    <ion-content>\n      <ion-card>\n        <ion-card-header>\n          <ion-card-subtitle>Link to a New Station</ion-card-subtitle>\n          <ion-card-title>Scan the QR Code on the IoT Node to link it to your account</ion-card-title>\n        </ion-card-header>\n\n        <ion-card-content>\n          <ion-button expand=\"block\" color=\"success\" (click)=\"scanQRCode()\">Scan QR Code</ion-button>\n          <ion-button expand=\"block\" (click)=\"closeStationModal()\">Cancel</ion-button>\n        </ion-card-content>\n      </ion-card>\n    </ion-content>\n  </ng-template>\n</ion-modal>");

/***/ }),

/***/ 6700:
/*!***************************************************!*\
  !*** ./node_modules/moment/locale/ sync ^\.\/.*$ ***!
  \***************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./af": 2139,
	"./af.js": 2139,
	"./ar": 2600,
	"./ar-dz": 1001,
	"./ar-dz.js": 1001,
	"./ar-kw": 9842,
	"./ar-kw.js": 9842,
	"./ar-ly": 9826,
	"./ar-ly.js": 9826,
	"./ar-ma": 5452,
	"./ar-ma.js": 5452,
	"./ar-sa": 1802,
	"./ar-sa.js": 1802,
	"./ar-tn": 4094,
	"./ar-tn.js": 4094,
	"./ar.js": 2600,
	"./az": 6375,
	"./az.js": 6375,
	"./be": 2086,
	"./be.js": 2086,
	"./bg": 5236,
	"./bg.js": 5236,
	"./bm": 1704,
	"./bm.js": 1704,
	"./bn": 8653,
	"./bn-bd": 4466,
	"./bn-bd.js": 4466,
	"./bn.js": 8653,
	"./bo": 7891,
	"./bo.js": 7891,
	"./br": 3348,
	"./br.js": 3348,
	"./bs": 4848,
	"./bs.js": 4848,
	"./ca": 5928,
	"./ca.js": 5928,
	"./cs": 1839,
	"./cs.js": 1839,
	"./cv": 9151,
	"./cv.js": 9151,
	"./cy": 5761,
	"./cy.js": 5761,
	"./da": 6686,
	"./da.js": 6686,
	"./de": 5177,
	"./de-at": 2311,
	"./de-at.js": 2311,
	"./de-ch": 4407,
	"./de-ch.js": 4407,
	"./de.js": 5177,
	"./dv": 9729,
	"./dv.js": 9729,
	"./el": 430,
	"./el.js": 430,
	"./en-au": 8430,
	"./en-au.js": 8430,
	"./en-ca": 1139,
	"./en-ca.js": 1139,
	"./en-gb": 6747,
	"./en-gb.js": 6747,
	"./en-ie": 9466,
	"./en-ie.js": 9466,
	"./en-il": 2121,
	"./en-il.js": 2121,
	"./en-in": 1167,
	"./en-in.js": 1167,
	"./en-nz": 2030,
	"./en-nz.js": 2030,
	"./en-sg": 3646,
	"./en-sg.js": 3646,
	"./eo": 3126,
	"./eo.js": 3126,
	"./es": 8819,
	"./es-do": 9293,
	"./es-do.js": 9293,
	"./es-mx": 5304,
	"./es-mx.js": 5304,
	"./es-us": 6068,
	"./es-us.js": 6068,
	"./es.js": 8819,
	"./et": 3291,
	"./et.js": 3291,
	"./eu": 1400,
	"./eu.js": 1400,
	"./fa": 43,
	"./fa.js": 43,
	"./fi": 6138,
	"./fi.js": 6138,
	"./fil": 1466,
	"./fil.js": 1466,
	"./fo": 6803,
	"./fo.js": 6803,
	"./fr": 5523,
	"./fr-ca": 697,
	"./fr-ca.js": 697,
	"./fr-ch": 9001,
	"./fr-ch.js": 9001,
	"./fr.js": 5523,
	"./fy": 1116,
	"./fy.js": 1116,
	"./ga": 6151,
	"./ga.js": 6151,
	"./gd": 2472,
	"./gd.js": 2472,
	"./gl": 1279,
	"./gl.js": 1279,
	"./gom-deva": 4458,
	"./gom-deva.js": 4458,
	"./gom-latn": 6320,
	"./gom-latn.js": 6320,
	"./gu": 8658,
	"./gu.js": 8658,
	"./he": 2153,
	"./he.js": 2153,
	"./hi": 8732,
	"./hi.js": 8732,
	"./hr": 4960,
	"./hr.js": 4960,
	"./hu": 6339,
	"./hu.js": 6339,
	"./hy-am": 1862,
	"./hy-am.js": 1862,
	"./id": 1068,
	"./id.js": 1068,
	"./is": 1260,
	"./is.js": 1260,
	"./it": 1007,
	"./it-ch": 8063,
	"./it-ch.js": 8063,
	"./it.js": 1007,
	"./ja": 6854,
	"./ja.js": 6854,
	"./jv": 2390,
	"./jv.js": 2390,
	"./ka": 5958,
	"./ka.js": 5958,
	"./kk": 7216,
	"./kk.js": 7216,
	"./km": 1061,
	"./km.js": 1061,
	"./kn": 4060,
	"./kn.js": 4060,
	"./ko": 5216,
	"./ko.js": 5216,
	"./ku": 894,
	"./ku.js": 894,
	"./ky": 609,
	"./ky.js": 609,
	"./lb": 3591,
	"./lb.js": 3591,
	"./lo": 8381,
	"./lo.js": 8381,
	"./lt": 6118,
	"./lt.js": 6118,
	"./lv": 7889,
	"./lv.js": 7889,
	"./me": 4274,
	"./me.js": 4274,
	"./mi": 9226,
	"./mi.js": 9226,
	"./mk": 528,
	"./mk.js": 528,
	"./ml": 7938,
	"./ml.js": 7938,
	"./mn": 5456,
	"./mn.js": 5456,
	"./mr": 4393,
	"./mr.js": 4393,
	"./ms": 3647,
	"./ms-my": 3049,
	"./ms-my.js": 3049,
	"./ms.js": 3647,
	"./mt": 6097,
	"./mt.js": 6097,
	"./my": 6277,
	"./my.js": 6277,
	"./nb": 7245,
	"./nb.js": 7245,
	"./ne": 3988,
	"./ne.js": 3988,
	"./nl": 2557,
	"./nl-be": 478,
	"./nl-be.js": 478,
	"./nl.js": 2557,
	"./nn": 9046,
	"./nn.js": 9046,
	"./oc-lnc": 3131,
	"./oc-lnc.js": 3131,
	"./pa-in": 1731,
	"./pa-in.js": 1731,
	"./pl": 8409,
	"./pl.js": 8409,
	"./pt": 1178,
	"./pt-br": 6558,
	"./pt-br.js": 6558,
	"./pt.js": 1178,
	"./ro": 4138,
	"./ro.js": 4138,
	"./ru": 3380,
	"./ru.js": 3380,
	"./sd": 2889,
	"./sd.js": 2889,
	"./se": 2774,
	"./se.js": 2774,
	"./si": 3776,
	"./si.js": 3776,
	"./sk": 9597,
	"./sk.js": 9597,
	"./sl": 3871,
	"./sl.js": 3871,
	"./sq": 4228,
	"./sq.js": 4228,
	"./sr": 774,
	"./sr-cyrl": 1928,
	"./sr-cyrl.js": 1928,
	"./sr.js": 774,
	"./ss": 3176,
	"./ss.js": 3176,
	"./sv": 2422,
	"./sv.js": 2422,
	"./sw": 2530,
	"./sw.js": 2530,
	"./ta": 5731,
	"./ta.js": 5731,
	"./te": 8025,
	"./te.js": 8025,
	"./tet": 3934,
	"./tet.js": 3934,
	"./tg": 9958,
	"./tg.js": 9958,
	"./th": 4251,
	"./th.js": 4251,
	"./tk": 5494,
	"./tk.js": 5494,
	"./tl-ph": 8568,
	"./tl-ph.js": 8568,
	"./tlh": 3158,
	"./tlh.js": 3158,
	"./tr": 9574,
	"./tr.js": 9574,
	"./tzl": 4311,
	"./tzl.js": 4311,
	"./tzm": 9686,
	"./tzm-latn": 2380,
	"./tzm-latn.js": 2380,
	"./tzm.js": 9686,
	"./ug-cn": 2356,
	"./ug-cn.js": 2356,
	"./uk": 4934,
	"./uk.js": 4934,
	"./ur": 4515,
	"./ur.js": 4515,
	"./uz": 58,
	"./uz-latn": 1875,
	"./uz-latn.js": 1875,
	"./uz.js": 58,
	"./vi": 3325,
	"./vi.js": 3325,
	"./x-pseudo": 9208,
	"./x-pseudo.js": 9208,
	"./yo": 8742,
	"./yo.js": 8742,
	"./zh-cn": 2378,
	"./zh-cn.js": 2378,
	"./zh-hk": 1074,
	"./zh-hk.js": 1074,
	"./zh-mo": 4671,
	"./zh-mo.js": 4671,
	"./zh-tw": 259,
	"./zh-tw.js": 259
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 6700;

/***/ }),

/***/ 836:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDJFQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTs7RUFFRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsMkRBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGdCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBRUEsbUJBQUE7RUFFQSxjQUFBO0VBRUEsZ0JBQUE7QUFIRjs7QUFNQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhGOztBQU1BO0VBQ0Usc0RBQUE7QUFIRjs7QUFNQTtFQUNFLCtCQUFBO0FBSEY7O0FBTUE7RUFDRSxjQUFBO0FBSEY7O0FBTUE7RUFDRSxnQkFBQTtBQUhGOztBQU1BO0VBQ0Usc0JBQUE7QUFIRjs7QUFNQTtFQUNFLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFIRjs7QUFNQTtFQUNFLCtCQUFBO0FBSEY7O0FBTUE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUhGOztBQU1BO0VBQ0Usa0JBQUE7QUFIRjs7QUFNQTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxrQkFBQTtBQUhGOztBQU1BO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsb0NBQUE7QUFKRjs7QUFPQTtFQUNFLGlDQUFBO0FBSkYiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW1lbnUgaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1pdGVtLWJhY2tncm91bmQsIHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yLCAjZmZmKSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1jb250ZW50IHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDhweDtcbiAgLS1wYWRkaW5nLXRvcDogMjBweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3Qge1xuICBwYWRkaW5nOiAyMHB4IDA7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QtaGVhZGVyLFxuaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3Qge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXN0ZXAtMTUwLCAjZDdkOGRhKTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjaW5ib3gtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBmb250LXNpemU6IDIycHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG5cbiAgbWluLWhlaWdodDogMjBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuXG4gIG1hcmdpbi1ib3R0b206IDE4cHg7XG5cbiAgY29sb3I6ICM3NTc1NzU7XG5cbiAgbWluLWhlaWdodDogMjZweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0uc2VsZWN0ZWQge1xuICAtLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXByaW1hcnktcmdiKSwgMC4xNCk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0gaW9uLWljb24ge1xuICBjb2xvcjogIzYxNmU3ZTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0gaW9uLWxhYmVsIHtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1jb250ZW50IHtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0IHtcbiAgcGFkZGluZzogMjBweCAwIDAgMDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMTZweDtcbiAgLS1wYWRkaW5nLWVuZDogMTZweDtcbiAgLS1taW4taGVpZ2h0OiA1MHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0gaW9uLWljb24ge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiAjNzM4NDlhO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWxpc3QtaGVhZGVyLFxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbmlvbi1ub3RlIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LXNpemU6IDE2cHg7XG5cbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xufVxuXG5pb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn0iXX0= */";

/***/ }),

/***/ 4754:
/*!**************************************************!*\
  !*** ./src/app/pages/login/login.component.scss ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsb2dpbi5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 9963:
/*!********************************************************!*\
  !*** ./src/app/pages/register/register.component.scss ***!
  \********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3Rlci5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 6755:
/*!*******************************************************************!*\
  !*** ./src/app/pages/stations/find-path/find-path.component.scss ***!
  \*******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmaW5kLXBhdGguY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 5273:
/*!***********************************************************************************!*\
  !*** ./src/app/pages/stations/station-dashboard/station-dashboard.component.scss ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdGF0aW9uLWRhc2hib2FyZC5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 5733:
/*!********************************************************!*\
  !*** ./src/app/pages/stations/stations.component.scss ***!
  \********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdGF0aW9ucy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 2480:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/***/ (() => {

/* (ignored) */

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(271)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map